// Auto-generated. Do not edit!

// (in-package subscriber.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class stop {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.emergency = null;
      this.wall = null;
      this.fence = null;
    }
    else {
      if (initObj.hasOwnProperty('emergency')) {
        this.emergency = initObj.emergency
      }
      else {
        this.emergency = false;
      }
      if (initObj.hasOwnProperty('wall')) {
        this.wall = initObj.wall
      }
      else {
        this.wall = false;
      }
      if (initObj.hasOwnProperty('fence')) {
        this.fence = initObj.fence
      }
      else {
        this.fence = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type stop
    // Serialize message field [emergency]
    bufferOffset = _serializer.bool(obj.emergency, buffer, bufferOffset);
    // Serialize message field [wall]
    bufferOffset = _serializer.bool(obj.wall, buffer, bufferOffset);
    // Serialize message field [fence]
    bufferOffset = _serializer.int8(obj.fence, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type stop
    let len;
    let data = new stop(null);
    // Deserialize message field [emergency]
    data.emergency = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [wall]
    data.wall = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [fence]
    data.fence = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'subscriber/stop';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c4a32ec960ded28b25576842e55933cd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool emergency
    bool wall
    int8 fence
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new stop(null);
    if (msg.emergency !== undefined) {
      resolved.emergency = msg.emergency;
    }
    else {
      resolved.emergency = false
    }

    if (msg.wall !== undefined) {
      resolved.wall = msg.wall;
    }
    else {
      resolved.wall = false
    }

    if (msg.fence !== undefined) {
      resolved.fence = msg.fence;
    }
    else {
      resolved.fence = 0
    }

    return resolved;
    }
};

module.exports = stop;
