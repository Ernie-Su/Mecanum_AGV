// Auto-generated. Do not edit!

// (in-package subscriber.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class stop {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.emergency = null;
      this.frontWall = null;
      this.backWall = null;
      this.fence = null;
    }
    else {
      if (initObj.hasOwnProperty('emergency')) {
        this.emergency = initObj.emergency
      }
      else {
        this.emergency = false;
      }
      if (initObj.hasOwnProperty('frontWall')) {
        this.frontWall = initObj.frontWall
      }
      else {
        this.frontWall = false;
      }
      if (initObj.hasOwnProperty('backWall')) {
        this.backWall = initObj.backWall
      }
      else {
        this.backWall = false;
      }
      if (initObj.hasOwnProperty('fence')) {
        this.fence = initObj.fence
      }
      else {
        this.fence = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type stop
    // Serialize message field [emergency]
    bufferOffset = _serializer.bool(obj.emergency, buffer, bufferOffset);
    // Serialize message field [frontWall]
    bufferOffset = _serializer.bool(obj.frontWall, buffer, bufferOffset);
    // Serialize message field [backWall]
    bufferOffset = _serializer.bool(obj.backWall, buffer, bufferOffset);
    // Serialize message field [fence]
    bufferOffset = _serializer.bool(obj.fence, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type stop
    let len;
    let data = new stop(null);
    // Deserialize message field [emergency]
    data.emergency = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [frontWall]
    data.frontWall = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [backWall]
    data.backWall = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [fence]
    data.fence = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'subscriber/stop';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e0271d30ae30497d7c7f8b7190e38c41';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool emergency
    bool frontWall
    bool backWall
    bool fence
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new stop(null);
    if (msg.emergency !== undefined) {
      resolved.emergency = msg.emergency;
    }
    else {
      resolved.emergency = false
    }

    if (msg.frontWall !== undefined) {
      resolved.frontWall = msg.frontWall;
    }
    else {
      resolved.frontWall = false
    }

    if (msg.backWall !== undefined) {
      resolved.backWall = msg.backWall;
    }
    else {
      resolved.backWall = false
    }

    if (msg.fence !== undefined) {
      resolved.fence = msg.fence;
    }
    else {
      resolved.fence = false
    }

    return resolved;
    }
};

module.exports = stop;
