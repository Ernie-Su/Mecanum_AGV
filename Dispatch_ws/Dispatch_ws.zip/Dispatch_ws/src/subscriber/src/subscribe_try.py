#!/usr/bin/env python

# ROS
import rospy
from subscriber.msg import joystick
from subscriber.msg import Node_recv
from subscriber.msg import stop
# Python
import threading
import socket
import struct
import time

def joystickCallback(joystick):

    print ("I heard %s, %s, %s" % (round(joystick.x, 3), round(joystick.y, 3), round(joystick.z, 3)))
    #client.send(command_byte)
    print("data sent!")
    rate = rospy.Rate(10)
    rate.sleep()

'''
def Node_recvCallback(Node_recv):
    continue
'''

def stop_publish():
    pub = rospy.Publisher('stop', stop, queue_size=10)
    rate = rospy.Rate(10) #10hz
    msg = stop()
    msg.emergency = True

    print "Connecting to Mission server ..."
    Server_host = "192.168.72.99"
    Server_port = 36000

    Mission_client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    #Mission_client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    Mission_client.bind((Server_host, Server_port))
    Mission_client.listen(10)
    client_socket,addr = Mission_client.accept()
    print "Mission server connected!"

    last_command = ''
    last_command_time = 0

    while True:
        print "Waiting for message ..."
        data = client_socket.recv(16)

        if data:
            if (data != last_command) or ((data == last_command) and ((time.time()-last_command_time) > 10)):
                print "Message received!"
                print str(data)

                '''
                if data == b'SHE':
                    rospy.loginfo(msg)
                    pub.publish(msg)
                    rate.sleep()
                    break
                elif data == b'SGE':
                    Navigate()
                '''
                if data == b'SGE':
                    Navigate()

                last_command = data
                last_command_time = time.time()
            
            if data == b'SHE':
                rospy.loginfo(msg)
                pub.publish(msg)
                rate.sleep()
                
            #time.sleep(0.5)
        else:
            client_socket,addr = Mission_client.accept()
    '''
    while not rospy.is_shutdown():
        rospy.loginfo(msg)
        pub.publish(msg)
        rate.sleep()
    '''

def Navigate():
    print "Starts navigation"
    #Anhung_UDP.sendto('Mr;0,0,-0.201,0.104,0.039,omni,0,1.0;1,6,3.665,-2.130,0.010,omni,0,1.0;2,6,0.201,0.104,0.039,omni,0,1.0;E'.encode('utf-8'), (Anhung_network, Anhung_PORT))
    #Anhung_UDP.sendto('Mr;0,0,-0.540,0.850,0.063,omni,0,1.0;1,6,4.120,0.957,0.082,omni,0,1.0;2,6,-0.540,0.850,0.063,omni,0,1.0;E'.encode('utf-8'), (Anhung_network, Anhung_PORT))
    #Anhung_UDP.sendto('Mr;0,0,-0.470,1.810,0.0,omni,0,1.0;1,3,2.340,1.910,0.0,omni,0,1.0,0;2,3,2.310,0.265,0.0,omni,0,1.0,0;3,4,5.079,0.230,0.0,omni,0,1.0;4,3,2.310,0.265,0.0,omni,0,1.0,0;5,3,2.340,1.910,0.0,omni,0,1.0,0;6,6,-0.470,1.810,0.0,omni,0,1.0;E'.encode('utf-8'), (Anhung_network, Anhung_PORT))
    #Anhung_UDP.sendto('Mr;0,0,-5.738,0.347,0.0,omni,0,1.0;1,3,-2.705,0.376,0.0,omni,0,1.0,0;2,3,-2.695,-0.169,0.0,omni,0,1.0,0;3,4,0.069,-0.091,0.0,omni,0,1.0,0;4,3,-2.695,-0.169,0.0,omni,0,1.0,0;5,3,-2.705,0.376,0.0,omni,0,1.0,0;6,6,-5.738,0.347,0.0,omni,0,1.0,0;E'.encode('utf-8'), (Anhung_network, Anhung_PORT))
    Anhung_UDP.sendto('Mr;0,0,-2.610,1.915,0.0,omni,0,1.0;1,3,-1.610,1.915,0.0,omni,0,1.0,0;2,3,-2.610,1.915,0.0,omni,0,1.0,0;E'.encode('utf-8'), (Anhung_network, Anhung_PORT))

Anhung_UDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
Anhung_UDP.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
Anhung_PORT = 9930
Anhung_network = "127.0.0.1"
print "Anhung setting finished"
'''
print "Connecting to Mission server ..."
Server_host = "192.168.72.197"
Server_port = 36000

Mission_client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#Mission_client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
Mission_client.bind((Server_host, Server_port))
Mission_client.listen(10)
client_socket,addr = Mission_client.accept()
print "Mission server connected!"
'''
#last_command = ''
#last_command_time = 0

def main():
    rospy.init_node('transfer', anonymous=True)
    
    #rospy.Subscriber("/joystick", joystick, joystickCallback)
    #rospy.Subscriber("/id", Node_recv, Node_recvCallback)
    #rospy.loginfo('starts subscribing')

    publish_thread = threading.Thread(target = stop_publish)
    publish_thread.start()
    rospy.loginfo('starts publishing')
    
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    publish_thread.join()

if __name__ == '__main__':
    main()
