#!/usr/bin/env python

import socket

class anhungUDP:
    def __init__(self):
        # Anhung UDP Server Initialize
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.PORT = 9930
        self.IP_ADDR = "127.0.0.1"
        print ("[Anhung  Control] UDP Connection Setting Finished.")
    
    def navigate(self):
        self.connection.sendto('Mr;0,0,18.465,0.569,3.14,omni,0,1.0;1,3,18.465,-0.056,3.14,omni,0,1.0,0;2,3,8.933,0.0457,3.14,omni,0,1.0,0;3,3,7.202,-0.011,3.14,omni,0,1.0,0;4,4,2.517,0.0,3.14,omni,0,1.0,0;5,6,-0.591,0.259,3.14,omni,0,1.0,0;E'.encode('utf-8'), (self.IP_ADDR, self.PORT))
        print ("[Anhung  Control] Starts Navigation.")