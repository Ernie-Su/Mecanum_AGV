#!/usr/bin/env python

# ROS
import rospy
from subscriber.msg import stop

# Python Library
import socket
import time
import agvInfo
import anhungUDP

class dispatchTCP:
    def __init__(self, stopPub):
        self.pub = stopPub

        try:
            self.connection = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            #self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # Re-use address when there's address in use error
            #self.connection.setblocking(0) # nonblocking

            IP_ADDR = "192.168.72.98"
            PORT = 36000
            self.connection.bind((IP_ADDR, PORT))
            self.connection.listen(10)
            self.dispatch_socket, self.addr = self.connection.accept()
        except Exception as e:
            print e

        self.connected = True
        self.commandReconnect = False
        self.statusReconnect = False

    def commandReceive(self, anhungUDP):
        rate = rospy.Rate(10) #10hz
        reconnectRate = rospy.Rate(1) #1hz
        msg = stop()
        msg.emergency = True

        last_command = ''
        last_command_time = 0

        while True:
            if self.connected == True:
                try:
                    print "[Dispatch System] Waiting for mission ..."
                    #data = self.dispatch_socket.recv(16, socket.MSG_DONTWAIT)
                    data = self.dispatch_socket.recv(16)

                    if data:
                        if (data != last_command) or ((data == last_command) and ((time.time() - last_command_time) > 10)):
                            print "[Dispatch System] Command Received!"
                            print str(data)

                            if data == b'SAE':
                                anhungUDP.pickUpA()
                            if data == b'SBE':
                                anhungUDP.pickUpB()
                            if data == b'SCE':
                                anhungUDP.chargeBattery()
                            if data == b'SDE':
                                anhungUDP.goBackIdle()                     

                            last_command = data
                            last_command_time = time.time()
                        
                        if data == b'SHE':
                            rospy.loginfo(msg)
                            self.pub.publish(msg)
                            rate.sleep()
                    #else:
                        #dispatch_socket,addr = Dispatch_System_TCP_server.accept()
                except Exception as e:
                    if str(e) != "timed out":
                        print e
                        self.connected = False
                    #break
            else:
                if self.statusReconnect == False:
                    print("[Dispatch System] commandReceive Thread Reconnecting Dispatch System...")
                    self.commandReconnect = True
                    self.dispatch_socket, self.addr = self.connection.accept()
                    self.connected = True
                    print("[Dispatch System] commandReceive Thread Successfully Reconnects Dispatch System!")
                else:
                    reconnectRate.sleep()

        print("[Dispatch System] commandReceive Thread Finished.")

        if self.connected == True:
            #self.connection.shutdown(socket.SHUT_RDWR)
            self.connection.close()
            self.connected = False
    
    def statusUpload(self, agvInfo):
        reconnectRate = rospy.Rate(1) #1hz

        while True:
            if self.connected == True:
                try:
                    command_byte = agvInfo.statusEncode()
                    self.dispatch_socket.send(command_byte)
                    reconnectRate.sleep()
                except Exception as e:
                    if str(e) != "timed out":
                        print e
                        self.connected = False
                    #break
            else:
                if self.commandReconnect == False:
                    print("[Dispatch System] commandReconnect Thread Reconnecting Dispatch System...")
                    self.statusReconnect = True          
                    self.dispatch_socket, self.addr = self.connection.accept()
                    self.connected = True
                    print("[Dispatch System] commandReconnect Thread Successfully Reconnects Dispatch System!")
                else:
                    reconnectRate.sleep()

        print("[Dispatch System] statusUpload Thread Finish")
        
        if self.connected == True:
            #self.connection.shutdown(socket.SHUT_RDWR)
            self.connection.close()
            self.connected = False
