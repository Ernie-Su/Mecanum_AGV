/* -------------------------------------------------------------------------- */
/*                                  ObsDetect                                 */
/*                            20210924 By Yu-An, Su                           */
/* -------------------------------------------------------------------------- */

#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <visualization_msgs/Marker.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <ros/package.h>
#include <vector>
#include "obstacle_detector/obstacle_publisher.h"
#include <math.h>
#include "geometry_msgs/PoseStamped.h"

// 211004 YuAn added stop topic
#include "obstacle_detector/stop.h"

// 220317 YuAn added centerPoint topic
#include "obstacle_detector/centerPoint.h"

/* -------------------------------------------------------------------------- */
/*                              ObsDetect class                               */
/* -------------------------------------------------------------------------- */

class ObsDetect
{
private:
  // ros
  ros::NodeHandle node;
  ros::NodeHandle pnh_;

  ros::Timer timer;
  ros::Publisher vis_pub;
  ros::Subscriber scan_sub;
  ros::Subscriber merged_cloud_sub;
  ros::Subscriber obstacle_sub;

  // 211004 YuAn added stop_pub
  ros::Publisher stop_pub;

  // 220317 YuAn added centerPoint_pub
  ros::Publisher centerPoint_pub;

  // struct
  typedef struct
  {
    double x;
    double y;
  } pos_t;

  typedef struct
  {
    double height;
    double width;
    double offset;
  } square_t;

  typedef struct
  {
    square_t range;
    int flag;
    int lastFlag;
    int pointCount;
  } fence_t;

  // 210917 YuAn add new data structure cabinet
  typedef struct
  {
    double center_x;
    double center_y;
    double obstacle_radius;
  } cabinet;

  // functions
  void timerCallback(const ros::TimerEvent &);
  void drawSquare(int id, double x1, double y1, double x2, double y2, int color, ros::Publisher vis_pub);
  void drawCircle(int id, double center_x, double center_y, double radius, int color, ros::Publisher vis_pub);
  void drawLine(double x, double y, double slope, int id, int color, ros::Publisher vis_pub);
  void scanSubCallback(const sensor_msgs::LaserScan &msg);
  void mergedCloudSubCallback(const sensor_msgs::PointCloud2 &msg);
  void obstacleSubCallback(const obstacle_detector::Obstacles::ConstPtr &msg);

  // var
  ros::Time now;
  //tf::TransformListener listener[4];
  tf::TransformListener listener;
  std::vector<tf::StampedTransform> transformVec;
  tf::StampedTransform transformer;
  //sensor_msgs::PointCloud out_pointcloud;  

  int fenceLevel;
  fence_t fenceStruct[10];
  int fenceCount;
  int doorCount;
  int stopFlag;
  int lastStopFlag;

  bool fenceStop;
  bool wallStop;

  pos_t origin_pos[2];

  // 210917 YuAn declare cabinet_leg
  cabinet cabinet_leg[4];

public:
  ObsDetect(/* args */);
  ~ObsDetect();
};

/* -------------------------------------------------------------------------- */
/*                             ObsDetect ObsDetect                            */
/* -------------------------------------------------------------------------- */

ObsDetect::ObsDetect(/* args */) : pnh_("~")
{
  // ros
  now = ros::Time::now();

  timer = node.createTimer(ros::Duration(0.1), &ObsDetect::timerCallback, this);
  vis_pub = node.advertise<visualization_msgs::Marker>("visualization_marker", 0, this);
  scan_sub = node.subscribe("scan", 1000, &ObsDetect::scanSubCallback, this);
  merged_cloud_sub = node.subscribe("merged_cloud", 1000, &ObsDetect::mergedCloudSubCallback, this);
  obstacle_sub = node.subscribe("raw_obstacles", 1000, &ObsDetect::obstacleSubCallback, this);
  
  // 211004 YuAn added stop_pub
  stop_pub = node.advertise<obstacle_detector::stop>("stop", 0, this);
  // 220317 YuAn added centerPoint_pub
  centerPoint_pub = node.advertise<obstacle_detector::centerPoint>("centerPoint", 0, this);

 // get param
  pnh_.param<int>("fence_level", fenceLevel, 2);
  pnh_.param<double>("fence_range_height", fenceStruct[0].range.height, 0.5); // 0.9m offsets 0.3m = 1.2m
  pnh_.param<double>("fence_range_width", fenceStruct[0].range.width, 0.6); // 1.1m offsets 0.3m = 1.4m
  fenceStruct[0].range.offset = 0.0;

  // fenceStruct[1].range.height = 1.2; 
  // fenceStruct[1].range.width = 1.4; 
  // fenceStruct[1].range.offset = 0.0;

  // fenceStruct[2].range.height = 0.25;
  // fenceStruct[2].range.width = 1.5;
  // fenceStruct[2].range.offset = 1.0;

  fenceStruct[1].range.height = 0.25; 
  fenceStruct[1].range.width = 1.5; 
  fenceStruct[1].range.offset = 1.0;

  for (int i=0 ; i < fenceLevel ; ++i)
  {
    std::cout << "fence_range_height " << i << ": " << fenceStruct[i].range.height << std::endl;
    std::cout << "fence_range_width " << i << ": " << fenceStruct[i].range.width << std::endl;
    std::cout << "fence_range_offset " << i << ": " << fenceStruct[i].range.offset << std::endl;
  }

  // YuAn reduced fenceCount from 50 to 10, add doorCount = 100
  fenceCount = 50;
  doorCount = 200;

  // print param
  std::cout << "########## param ################" << std::endl;
  std::cout << "fence_range_height: " << fenceStruct[0].range.height << std::endl;
  std::cout << "fence_range_width: " << fenceStruct[0].range.width << std::endl;
  std::cout << "fenceCount: " << fenceCount << std::endl;
  std::cout << "doorCount: " << doorCount << std::endl;
  std::cout << "#################################" << std::endl;

  for (int i=0 ; i<4 ; ++i)
  {
    cabinet_leg[i].center_x = 0;
    cabinet_leg[i].center_y = 0;
    cabinet_leg[i].obstacle_radius = 0;
  }

  // draw
  for (int i = 0; i < fenceLevel ; i++)
  {
    fenceStruct[i].flag = 0;
    //drawSquare(i+1, origin_pos[0].x + fenceStruct[i].range.height, origin_pos[0].y + fenceStruct[i].range.width, origin_pos[1].x - fenceStruct[i].range.height, origin_pos[1].y - fenceStruct[i].range.width, 2, vis_pub);
  }
  
  fenceStop = false;
  wallStop = false;

}

ObsDetect::~ObsDetect()
{
}

/* -------------------------------------------------------------------------- */
/*                                    timer                                   */
/* -------------------------------------------------------------------------- */

void ObsDetect::timerCallback(const ros::TimerEvent &)
{
  drawSquare(0, -0.55, -0.45, 0.55, 0.45, 4, vis_pub); // draw the car

  //draw the fence
  for (int i = 0; i < fenceLevel; i++)
  {
    if (fenceStruct[i].flag)
      drawSquare(i+1, origin_pos[0].x + fenceStruct[i].range.height/2.0 + fenceStruct[i].range.offset, origin_pos[0].y + fenceStruct[i].range.width/2.0, origin_pos[1].x - fenceStruct[i].range.height/2.0 + fenceStruct[i].range.offset, origin_pos[1].y - fenceStruct[i].range.width/2.0, 1, vis_pub);
    else
      drawSquare(i+1, origin_pos[0].x + fenceStruct[i].range.height/2.0 + fenceStruct[i].range.offset, origin_pos[0].y + fenceStruct[i].range.width/2.0, origin_pos[1].x - fenceStruct[i].range.height/2.0 + fenceStruct[i].range.offset, origin_pos[1].y - fenceStruct[i].range.width/2.0, 2, vis_pub);
  }
}

/* -------------------------------------------------------------------------- */
/*                               subscribe scan                               */
/* -------------------------------------------------------------------------- */

void ObsDetect::scanSubCallback(const sensor_msgs::LaserScan &msg)
{
    
  sensor_msgs::LaserScan device_scan_1;
  
  ros::Duration dur(0.5);

  device_scan_1.header = msg.header;
  device_scan_1.angle_min = msg.angle_min;
  device_scan_1.angle_max = msg.angle_max;
  device_scan_1.angle_increment = msg.angle_increment;
  device_scan_1.time_increment = msg.time_increment;
  device_scan_1.scan_time = msg.scan_time;
  device_scan_1.range_min = msg.range_min;
  device_scan_1.range_max = msg.range_max;
  device_scan_1.ranges.resize(msg.ranges.size());
  device_scan_1.intensities.resize(msg.ranges.size());

  for (int i = 0; i < msg.ranges.size(); i++)
    device_scan_1.ranges[i] = msg.ranges[i];

  if (listener.waitForTransform("base_link", device_scan_1.header.frame_id, device_scan_1.header.stamp, dur))
	{
		listener.lookupTransform("base_link", device_scan_1.header.frame_id, device_scan_1.header.stamp, transformer);
    //projector_1_.projectLaser(device_scan_1, laser_point_cloud_1_, 20.0);
   	//tf::Vector3 laserPos_1(laserTransform_1.getOrigin());
    origin_pos[0].x = transformer.getOrigin().x();
    origin_pos[0].y = transformer.getOrigin().y();
    origin_pos[1].x = transformer.getOrigin().x();
    origin_pos[1].y = transformer.getOrigin().y();
		//std::cout << "transformer = " << transformer.getOrigin().x() << transformer.getOrigin().y() << std::endl;
  }
}

/* -------------------------------------------------------------------------- */
/*                          subscribe mergedCloudSub                          */
/* -------------------------------------------------------------------------- */

void ObsDetect::mergedCloudSubCallback(const sensor_msgs::PointCloud2 &msg)
{
  sensor_msgs::PointCloud out_pointcloud; 
  sensor_msgs::convertPointCloud2ToPointCloud(msg, out_pointcloud); //pointclound2 to pointclound 
  obstacle_detector::stop stop;
  
  for (int i = 0; i < fenceLevel ; i++)
  {
    fenceStruct[i].pointCount = 0;
  }

  //std::cout << "out_pointcloud.points.size() = " << out_pointcloud.points.size() << std::endl;

  // fence
  for (int i = 0; i < out_pointcloud.points.size(); i++)
  {
    for (int j = 0; j < fenceLevel; j++)
    {
      if ((out_pointcloud.points[i].x < (origin_pos[0].x + fenceStruct[j].range.height/2.0 + fenceStruct[j].range.offset)) && (out_pointcloud.points[i].x > (origin_pos[0].x - fenceStruct[j].range.height/2.0 + fenceStruct[j].range.offset))) // if x point inside the fence
      {
        if ((out_pointcloud.points[i].y < fenceStruct[j].range.width/2.0) && (out_pointcloud.points[i].y > fenceStruct[j].range.width/(-2.0)))
        {
          fenceStruct[j].pointCount++; // how many point ++
          //std::cout << "fenceStruct[j].pointCount++" << std::endl;
        }
      }
      //std::cout << "fenceStruct[" << j << "].pointCount = " << fenceStruct[j].pointCount << std::endl;
    }
  }

  stopFlag = 0;
  for (int i = 0; i < fenceLevel-1 ; i++)
  {
    // std::cout << "fenceStruct[" << i << "].pointCount = " << fenceStruct[i].pointCount << std::endl;
    if (!(fenceStruct[i].pointCount > fenceCount))
      stopFlag++;
  }

  //std::cout << "stopFlag" << std::endl;

  for (int i = fenceLevel-1 ; i >= 0 ; i--)
  {
    // std::cout << "fence" << i << ":" << fenceStruct[i].pointCount << std::endl;
    if (fenceStruct[i].pointCount > fenceCount) // something inside fence
    {
      fenceStruct[i].flag = 1;
      if (i == 0) // fence level sound speed
      {
        ROS_INFO("*** Obs!!! ***");
        stop.fence = 2;
      }
      // else if (i == 1)
      // {
      //   ROS_INFO("*** Slower ***");
      //   stop.fence = 1;
      //   //std::cout << i << " " << fenceStruct[i].pointCount << std::endl; // debug print
      // }
    }
    else
    {
      // std::cout << fenceStruct[i].pointCount << std::endl; // debug print
      fenceStruct[i].flag = 0;
      stop.fence = 0;
    }
    // fenceStruct[i].lastFlag = fenceStruct[i].flag; // record last flag
    // lastStopFlag = stopFlag;
  }

  //std::cout << "fence" << std::endl;
  // std::cout << "fenceStruct[2].pointCount = " << fenceStruct[2].pointCount << std::endl;
  // if (fenceStruct[2].pointCount > doorCount) // something inside door area
  // {
  //   fenceStruct[2].flag = 1;
  //   stop.wall = true;
  //   ROS_INFO("*** Door!! ***");
  // }
  // else
  // {
  //   fenceStruct[2].flag = 0;
  //   stop.wall = false;
  // }

  if (fenceStruct[1].pointCount > doorCount) // something inside door area
  {
    fenceStruct[1].flag = 1;
    stop.wall = true;
    ROS_INFO("*** Door!! ***");
  }
  else
  {
    fenceStruct[1].flag = 0;
    stop.wall = false;
  }

  //std::cout << "Door" << std::endl;

  stop_pub.publish(stop);

  //std::cout << "publish" << std::endl;
}


/* -------------------------------------------------------------------------- */
/*                             subscribe obstacle                             */
/* -------------------------------------------------------------------------- */

void ObsDetect::obstacleSubCallback(const obstacle_detector::Obstacles::ConstPtr &msg)
{
  obstacle_detector::centerPoint centerPoint;
  int leg_count = 0;
  //double distance = 0.0;

  double x_diff_1 = 0.0;
  double y_diff_1 = 0.0;
  double x_diff_2 = 0.0;
  double y_diff_2 = 0.0;
  double x_diff_3 = 0.0;
  double y_diff_3 = 0.0;
  double x_diff_4 = 0.0;
  double y_diff_4 = 0.0;

  double distance = 0.0;

  double x_mid_1 = 0.0;
  double y_mid_1 = 0.0;
  double x_mid_2 = 0.0;
  double y_mid_2 = 0.0;
  double x_mid_3 = 0.0;
  double y_mid_3 = 0.0;
  double x_mid_4 = 0.0;
  double y_mid_4 = 0.0;

  double slope_1 = 0.0;
  double perpendicular_slope_1 = 0.0;
  double slope_2 = 0.0;
  double perpendicular_slope_2 = 0.0;
  double slope_3 = 0.0;
  double perpendicular_slope_3 = 0.0;
  double slope_4 = 0.0;
  double perpendicular_slope_4 = 0.0;

  double orient_half_len = 0.45;
  double x_more = 0.0;
  double y_more = 0.0;

  double b1 = 0.0;
  double b2 = 0.0;

  double x1 = 0.0;
  double x2 = 0.0;
  double y1 = 0.0;
  double y2 = 0.0;

  double pointDistance = 0.0;

  double cabinet_slope = 0.0;
  double correct_yaw = 0.0;

  geometry_msgs::Point p1;

  geometry_msgs::Point dim_1, dim_2, dim_3, dim_4;
  bool dim_1_leg, dim_2_leg, dim_3_leg, dim_4_leg;

  dim_1.x = 0.0;
  dim_1.y = 0.0;
  dim_2.x = 0.0;
  dim_2.y = 0.0;
  dim_3.x = 0.0;
  dim_3.y = 0.0;
  dim_4.x = 0.0;
  dim_4.y = 0.0;

  dim_1_leg = false;
  dim_2_leg = false;
  dim_3_leg = false;
  dim_4_leg = false;

  if(!msg->circles.empty()){
    for (int i=0 ; i<msg->circles.size() ; ++i){
      distance = sqrt(msg->circles[i].center.x * msg->circles[i].center.x + msg->circles[i].center.y * msg->circles[i].center.y);

      // 220414 YuAn define x -> vertical, y -> horizontal

      // if radius is appropriate
      if (msg->circles[i].radius < 0.2){ 
        drawCircle(i+5, msg->circles[i].center.x, msg->circles[i].center.y, msg->circles[i].radius, 1, vis_pub);
        cabinet_leg[leg_count].center_x = msg->circles[i].center.x;
        cabinet_leg[leg_count].center_y = msg->circles[i].center.y;
        cabinet_leg[leg_count].obstacle_radius = msg->circles[i].true_radius;
        std::cout << "x = " << msg->circles[i].center.x << ", y = " << msg->circles[i].center.y << " , distance = " << distance << ", radius = " << msg->circles[i].radius <<  std::endl;
        leg_count++;
      }
      else{
        drawCircle(i+5, msg->circles[i].center.x, msg->circles[i].center.y, msg->circles[i].radius, 2, vis_pub);
      }
    }
    //std::cout << "Leg : " << leg_count << std::endl;

    switch(leg_count)
    {
      case 2:
        std::cout << "Leg : 2" << std::endl;
        x_diff_1 = cabinet_leg[0].center_x - cabinet_leg[1].center_x;
        y_diff_1 = cabinet_leg[0].center_y - cabinet_leg[1].center_y;

        pointDistance = sqrt(x_diff_1 * x_diff_1 + y_diff_1 * y_diff_1);

        if (pointDistance < 1)
        {
          x_mid_1 = (cabinet_leg[0].center_x + cabinet_leg[1].center_x)/2;
          y_mid_1 = (cabinet_leg[0].center_y + cabinet_leg[1].center_y)/2;

          // multiply two perpendicular lines' slope equals -1
          slope_1 = y_diff_1/x_diff_1;
          perpendicular_slope_1 = (-1.0)/slope_1;

          // x = sqrt( (hypotenuse^2) / (1 + slope^2) )
          // y = x * slope
          x_more = sqrt((orient_half_len * orient_half_len)/(1 + (perpendicular_slope_1 * perpendicular_slope_1)));
          x_more *= -1.0;

          y_more = x_more * perpendicular_slope_1;

          p1.x = x_mid_1 - x_more;
          p1.y = y_mid_1 - y_more;

          if ((p1.x > -0.1) && (fabs(p1.y) < 0.5) && (fabs(correct_yaw) < 0.6))
          {
            std::cout << "cabinet.x  = " << p1.x << ", cabinet.y  = " << p1.y << ", angle_diff = " << atan(perpendicular_slope_1) * 180 / M_PI << std::endl;
            drawCircle(10, p1.x, p1.y, 0.15, 2, vis_pub);
            centerPoint.legDetected = true;
            centerPoint.leg = 2;
            centerPoint.x = p1.x;
            centerPoint.y = p1.y;
            centerPoint.yaw = atan(perpendicular_slope_1);
            drawLine(p1.x, p1.y, slope_1, 4, 3, vis_pub);
          }
          else
          {
            std::cout << "not correct, Point = (" << p1.x << ", " << p1.y << "), Yaw = " << atan(perpendicular_slope_1) * 180 / M_PI << std::endl;
            centerPoint.legDetected = false;
          }
        }
        else
        {
          std::cout << "2 point not correct" << std::endl;
          centerPoint.legDetected = false;
        }
      break;

      case 3:
        std::cout << "Leg : 3" << std::endl;
        double correct_slope;
        x_diff_1 = cabinet_leg[0].center_x - cabinet_leg[1].center_x;
        y_diff_1 = cabinet_leg[0].center_y - cabinet_leg[1].center_y;
        x_mid_1 = (cabinet_leg[0].center_x + cabinet_leg[1].center_x)/2;
        y_mid_1 = (cabinet_leg[0].center_y + cabinet_leg[1].center_y)/2;

        x_diff_2 = cabinet_leg[1].center_x - cabinet_leg[2].center_x;
        y_diff_2 = cabinet_leg[1].center_y - cabinet_leg[2].center_y;
        x_mid_2 = (cabinet_leg[1].center_x + cabinet_leg[2].center_x)/2;
        y_mid_2 = (cabinet_leg[1].center_y + cabinet_leg[2].center_y)/2;

        // multiply two perpendicular lines' slope equals -1
        slope_1 = y_diff_1/x_diff_1;
        perpendicular_slope_1 = (-1.0)/slope_1;

        // multiply two perpendicular lines' slope equals -1
        slope_2 = y_diff_2/x_diff_2;
        perpendicular_slope_2 = (-1.0)/slope_2;

        // y_mid_1 = ps_1*x_mid_1 + b1
        // y_mid_2 = ps_2*x_mid_2 + b2
        b1 = y_mid_1 - perpendicular_slope_1*x_mid_1;
        b2 = y_mid_2 - perpendicular_slope_2*x_mid_2;

        p1.x = (b2 - b1) / (perpendicular_slope_1 - perpendicular_slope_2);
        p1.y = perpendicular_slope_1 * p1.x + b1;

        if (fabs(perpendicular_slope_1) > fabs(perpendicular_slope_2))
          cabinet_slope = perpendicular_slope_1;
        else
          cabinet_slope = perpendicular_slope_2;

        for(int k=0 ; k<3 ; ++k)
        {
          double cabi_x = (cabinet_leg[k].center_x - p1.x);
          double cabi_y = (cabinet_leg[k].center_y - p1.y);

          if ((cabi_x >= 0) && (cabi_y >= 0))
          {
            dim_1.x = cabinet_leg[k].center_x;
            dim_1.y = cabinet_leg[k].center_y;
            dim_1_leg = true;
          }
          if ((cabi_x < 0) && (cabi_y >= 0))
          {
            dim_2.x = cabinet_leg[k].center_x;
            dim_2.y = cabinet_leg[k].center_y;
            dim_2_leg = true;
          }
          if ((cabi_x < 0) && (cabi_y < 0))
          {
            dim_3.x = cabinet_leg[k].center_x;
            dim_3.y = cabinet_leg[k].center_y;
            dim_3_leg = true;
          }
          if ((cabi_x >= 0) && (cabi_y < 0))
          {
            dim_4.x = cabinet_leg[k].center_x;
            dim_4.y = cabinet_leg[k].center_y;
            dim_4_leg = true;
          }
        }

        double temp_x_mid, temp_y_mid;

        if (dim_1_leg && dim_2_leg)
        {
          temp_x_mid = (dim_1.x + dim_2.x)/2;
          temp_y_mid = (dim_1.y + dim_2.y)/2;
          //cabinet_slope = (temp_y_mid - p1.y) / (temp_x_mid - p1.x);
          cabinet_slope = -(temp_x_mid - p1.x) / (temp_y_mid - p1.y);
          std::cout << "dim 1 and 2 , Yaw = " << atan(cabinet_slope) * 180 / M_PI << std::endl; 
        }
        else if (dim_3_leg && dim_4_leg)
        {
          temp_x_mid = (dim_3.x + dim_4.x)/2;
          temp_y_mid = (dim_3.y + dim_4.y)/2;
          cabinet_slope = -(p1.x - temp_x_mid) / (p1.y - temp_y_mid);
          std::cout << "dim 3 and 4 , Yaw = " << atan(cabinet_slope) * 180 / M_PI << std::endl; 
        }

        correct_yaw = cabinet_slope;
        // if ((atan(cabinet_slope) + M_PI/2) > M_PI/2)
        // {
        //   correct_yaw = (atan(cabinet_slope) - M_PI/2);
        // }
        // else
        // {
        //   correct_yaw = (atan(cabinet_slope) + M_PI/2);
        // }

        if ((p1.x > -0.1) && (fabs(p1.y) < 0.5) && (fabs(correct_yaw) < 0.3))
        {
          std::cout << "cabinet.x  = " << p1.x << ", cabinet.y  = " << p1.y << ", angle_diff = " << correct_yaw * 180 / M_PI << std::endl;
          drawCircle(10, p1.x, p1.y, 0.15, 2, vis_pub);
          centerPoint.legDetected = true;
          centerPoint.leg = 3;
          centerPoint.x = p1.x;
          centerPoint.y = p1.y;
          //centerPoint.yaw = atan2(p1.y, p1.x);
          //centerPoint.yaw = (atan(perpendicular_slope_1) - M_PI/2);
          centerPoint.yaw = correct_yaw;
          //drawLine(p1.x, p1.y, 0, 4, 3, vis_pub);
          //drawLine(p1.x, p1.y, (perpendicular_slope_1 - M_PI/2), 4, 3, vis_pub);
          drawLine(p1.x, p1.y, tan(correct_yaw - M_PI/2), 4, 3, vis_pub);
          //centerPoint_pub.publish(centerPoint);
        }
        else
        {
          std::cout << "not correct, Point = (" << p1.x << ", " << p1.y << "), Yaw = " << correct_yaw << std::endl;
          centerPoint.legDetected = false;
        }
      break;
      
      case 4:
        std::cout << "Leg : 4" << std::endl;
        x_diff_1 = cabinet_leg[0].center_x - cabinet_leg[1].center_x;
        y_diff_1 = cabinet_leg[0].center_y - cabinet_leg[1].center_y;
        x_mid_1 = (cabinet_leg[0].center_x + cabinet_leg[1].center_x)/2;
        y_mid_1 = (cabinet_leg[0].center_y + cabinet_leg[1].center_y)/2;

        x_diff_2 = cabinet_leg[1].center_x - cabinet_leg[2].center_x;
        y_diff_2 = cabinet_leg[1].center_y - cabinet_leg[2].center_y;
        x_mid_2 = (cabinet_leg[1].center_x + cabinet_leg[2].center_x)/2;
        y_mid_2 = (cabinet_leg[1].center_y + cabinet_leg[2].center_y)/2;

        x_diff_3 = cabinet_leg[2].center_x - cabinet_leg[3].center_x;
        y_diff_3 = cabinet_leg[2].center_y - cabinet_leg[3].center_y;
        x_mid_3 = (cabinet_leg[2].center_x + cabinet_leg[3].center_x)/2;
        y_mid_3 = (cabinet_leg[2].center_y + cabinet_leg[3].center_y)/2;

        x_diff_4 = cabinet_leg[3].center_x - cabinet_leg[0].center_x;
        y_diff_4 = cabinet_leg[3].center_y - cabinet_leg[0].center_y;
        x_mid_4 = (cabinet_leg[3].center_x + cabinet_leg[0].center_x)/2;
        y_mid_4 = (cabinet_leg[3].center_y + cabinet_leg[0].center_y)/2;

        // multiply two perpendicular lines' slope equals -1
        slope_1 = y_diff_1/x_diff_1;
        perpendicular_slope_1 = (-1.0)/slope_1;

        // multiply two perpendicular lines' slope equals -1
        slope_2 = y_diff_2/x_diff_2;
        perpendicular_slope_2 = (-1.0)/slope_2;

        // multiply two perpendicular lines' slope equals -1
        slope_3 = y_diff_3/x_diff_3;
        perpendicular_slope_3 = (-1.0)/slope_3;

        // multiply two perpendicular lines' slope equals -1
        slope_4 = y_diff_4/x_diff_4;
        perpendicular_slope_4 = (-1.0)/slope_4;

        // y_mid_1 = ps_1*x_mid_1 + b1
        // y_mid_2 = ps_2*x_mid_2 + b2
        b1 = y_mid_1 - perpendicular_slope_1*x_mid_1;
        b2 = y_mid_2 - perpendicular_slope_2*x_mid_2;

        x1 = (b2 - b1) / (perpendicular_slope_1 - perpendicular_slope_2);
        y1 = perpendicular_slope_1 * x1 + b1;

        b1 = y_mid_3 - perpendicular_slope_3*x_mid_3;
        b2 = y_mid_4 - perpendicular_slope_4*x_mid_4;

        x2 = (b2 - b1) / (perpendicular_slope_3 - perpendicular_slope_4);
        y2 = perpendicular_slope_2 * x2 + b2;

        p1.x = (x1 + x2) / 2;
        p1.y = (y1 + y2) / 2;

        cabinet_slope = (y_mid_3 - y_mid_1) / (x_mid_3 - x_mid_1);

        if ((p1.x > -0.1) && (fabs(p1.y) < 0.3))
        {
          if ((atan(cabinet_slope) + M_PI/2) > M_PI/2)
          {
            correct_yaw = (atan(cabinet_slope) - M_PI/2);
          }
          else
          {
            correct_yaw = (atan(cabinet_slope) + M_PI/2);
          }

          std::cout << "cabinet.x  = " << p1.x << ", cabinet.y  = " << p1.y << ", angle_diff = " << correct_yaw * 180 / M_PI << std::endl;
          drawCircle(10, p1.x, p1.y, 0.15, 2, vis_pub);
          centerPoint.legDetected = true;
          centerPoint.leg = 4;
          centerPoint.x = p1.x;
          centerPoint.y = p1.y;
          centerPoint.yaw = correct_yaw; // other way

          drawLine(p1.x, p1.y, tan(correct_yaw - M_PI/2), 4, 3, vis_pub);
        }
        else
        {
          std::cout << "not correct, Point = (" << p1.x << ", " << p1.y << ")" << std::endl;
          centerPoint.legDetected = false;
        }
      break;

      default:
        centerPoint.legDetected = false;
      break;
    }
  }
  centerPoint_pub.publish(centerPoint);
  leg_count = 0;
}

/* -------------------------------------------------------------------------- */
/*                                  marker id                                 */
/*                      square : 0 -> car, 1 -> inner_fence,                  */
/*                               2 -> outer_fence, 3 -> door_detect           */
/*                      line : 4 -> mid_line                                  */
/*                      circle : 5 -> circles                                 */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/*                             marker draw square                             */
/* -------------------------------------------------------------------------- */

void ObsDetect::drawSquare(int id, double x1, double y1, double x2, double y2, int color, ros::Publisher vis_pub)
{

  visualization_msgs::Marker marker;
  marker.header.frame_id = "base_link";
  marker.header.stamp = ros::Time();
  marker.ns = "square";
  marker.id = id;
  marker.type = visualization_msgs::Marker::LINE_STRIP;
  marker.action = visualization_msgs::Marker::ADD;

  marker.scale.x = 0.05;
  marker.color.a = 1.0; // Don't forget to set the alpha!
  switch (color)
  {
  case 0:
    break;
  case 1:
    marker.color.r = 1.0;
    break;
  case 2:
    marker.color.g = 1.0;
    break;
  case 3:
    marker.color.b = 1.0;
    break;
  default:
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    break;
  }

  std::vector<geometry_msgs::Point> pointMsgVec(5);
  int qqX[5] = {0, 0, 1, 1, 0}; // square x
  int qqY[5] = {0, 1, 1, 0, 0}; // square y
  double posX[2] = {x1, x2};
  double posY[2] = {y1, y2};

  for (int i = 0; i < 5; i++)
  {
    pointMsgVec[i].x = posX[qqX[i]];
    pointMsgVec[i].y = posY[qqY[i]];

    marker.points.push_back(pointMsgVec[i]);
  }

  vis_pub.publish(marker);
}

/* -------------------------------------------------------------------------- */
/*                             marker draw circle                             */
/* -------------------------------------------------------------------------- */

void ObsDetect::drawCircle(int id, double center_x, double center_y, double radius, int color, ros::Publisher vis_pub)
{

  visualization_msgs::Marker marker;
  marker.header.frame_id = "base_link";
  marker.header.stamp = ros::Time();
  marker.ns = "circle";
  marker.id = id;
  marker.type = visualization_msgs::Marker::SPHERE;
  marker.action = visualization_msgs::Marker::ADD;
  marker.lifetime = ros::Duration(0.05);

  marker.scale.x = radius;
  marker.scale.y = radius;
  marker.scale.z = 0.01;
  marker.color.a = 0.5; // Don't forget to set the alpha!

  switch (color)
  {
  case 0:
    break;
  case 1:
    marker.color.r = 1.0;
    break;
  case 2:
    marker.color.g = 1.0;
    break;
  case 3:
    marker.color.b = 1.0;
    break;
  default:
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    break;
  }

  marker.pose.position.x = center_x;
  marker.pose.position.y = center_y;

  vis_pub.publish(marker);
}

/* -------------------------------------------------------------------------- */
/*                              marker draw line                              */
/* -------------------------------------------------------------------------- */

void ObsDetect::drawLine(double x, double y, double slope, int id, int color, ros::Publisher vis_pub)
{
  
  double calculated_slope = y / x;
  if (slope != 0)
    calculated_slope = (-1.0)/slope;

  //double perpendicular_slope = ;

  double orient_half_len = 0.45;
  double x_more = 0.0;
  double y_more = 0.0;

  visualization_msgs::Marker marker;
  marker.header.frame_id = "base_link";
  marker.header.stamp = ros::Time();
  marker.ns = "line";
  marker.id = id;
  marker.type = visualization_msgs::Marker::ARROW;
  marker.action = visualization_msgs::Marker::ADD;
  marker.lifetime = ros::Duration(0.05);

  /*
  marker.pose.position.x = poseWorld.x();
  marker.pose.position.y = poseWorld.y();
  marker.pose.orientation.w = cos(poseWorld.z()*0.5f);
  marker.pose.orientation.z = sin(poseWorld.z()*0.5f);
  */
  marker.scale.x = 0.05;
  marker.color.a = 0.5; // Don't forget to set the alpha!

  switch (color)
  {
  case 0:
    break;
  case 1:
    marker.color.r = 1.0;
    break;
  case 2:
    marker.color.g = 1.0;
    break;
  case 3:
    marker.color.b = 1.0;
    break;
  default:
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    break;
  }

  // x_more = sqrt((orient_half_len * orient_half_len)/(1 + (perpendicular_slope * perpendicular_slope)));
  // y_more = x_more * perpendicular_slope;

  x_more = sqrt((orient_half_len * orient_half_len)/(1 + (calculated_slope * calculated_slope)));
  y_more = x_more * calculated_slope;

  geometry_msgs::Point p1, p2;

  p1.x = x + x_more;
  p1.y = y + y_more;

  p2.x = x - x_more;
  p2.y = y - y_more;

  marker.points.push_back(p1);
  marker.points.push_back(p2);

  vis_pub.publish(marker);
}

/* -------------------------------------------------------------------------- */
/*                                    main                                    */
/* -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
  ros::init(argc, argv, "fence");

  ObsDetect ObsDetect;

  ros::spin();

  return 0;
};