/* -------------------------------------------------------------------------- */
/*                                  ObsDetect                                 */
/*                            20210924 By Yu-An, Su                           */
/* -------------------------------------------------------------------------- */

#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <visualization_msgs/Marker.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <ros/package.h>
#include <vector>
#include "obstacle_detector/obstacle_publisher.h"
#include <math.h>
#include "geometry_msgs/PoseStamped.h"

// 211004 YuAn added stop topic
#include "obstacle_detector/stop.h"

/* -------------------------------------------------------------------------- */
/*                              ObsDetect class                               */
/* -------------------------------------------------------------------------- */

class ObsDetect
{
private:
  // ros
  ros::NodeHandle node;
  ros::NodeHandle pnh_;

  ros::Timer timer;
  ros::Publisher vis_pub;
  ros::Subscriber scan_sub;
  ros::Subscriber merged_cloud_sub;
  ros::Subscriber obstacle_sub;
  // 211004 YuAn added stop_pub
  ros::Publisher stop_pub;

  // struct
  typedef struct
  {
    double x;
    double y;
  } pos_t;

  typedef struct
  {
    double height;
    double width;
    double offset;
  } square_t;

  typedef struct
  {
    square_t range;
    int flag;
    int lastFlag;
    int pointCount;
  } fence_t;

  // 210917 YuAn add new data structure cabinet
  typedef struct
  {
    double center_x;
    double center_y;
    double obstacle_radius;
  } cabinet;

  // functions
  void timerCallback(const ros::TimerEvent &);
  void drawSquare(int id, double x1, double y1, double x2, double y2, int color, ros::Publisher vis_pub);
  void drawCircle(int id, double center_x, double center_y, double radius, int color, ros::Publisher vis_pub);
  void drawLine(cabinet c1, cabinet c2, int id, int color, ros::Publisher vis_pub);
  void scanSubCallback(const sensor_msgs::LaserScan &msg);
  void mergedCloudSubCallback(const sensor_msgs::PointCloud2 &msg);
  void obstacleSubCallback(const obstacle_detector::Obstacles::ConstPtr &msg);

  // var
  ros::Time now;
  tf::TransformListener listener[4];
  std::vector<tf::StampedTransform> transformVec;

  int fenceLevel;
  fence_t fenceStruct[10];
  int fenceCount;
  int doorCount;
  int stopFlag;
  int lastStopFlag;

  pos_t origin_pos[2];

  // 210917 YuAn declare cabinet_leg
  cabinet cabinet_leg[4];

public:
  ObsDetect(/* args */);
  ~ObsDetect();
};

/* -------------------------------------------------------------------------- */
/*                             ObsDetect ObsDetect                            */
/* -------------------------------------------------------------------------- */

ObsDetect::ObsDetect(/* args */) : pnh_("~")
{
  // ros
  now = ros::Time::now();

  timer = node.createTimer(ros::Duration(0.5), &ObsDetect::timerCallback, this);
  vis_pub = node.advertise<visualization_msgs::Marker>("visualization_marker", 0, this);
  scan_sub = node.subscribe("scan", 1000, &ObsDetect::scanSubCallback, this);
  merged_cloud_sub = node.subscribe("merged_cloud", 1000, &ObsDetect::mergedCloudSubCallback, this);
  obstacle_sub = node.subscribe("raw_obstacles", 1000, &ObsDetect::obstacleSubCallback, this);
  // 211004 YuAn added stop_pub
  stop_pub = node.advertise<obstacle_detector::stop>("stop", 0, this);


  // get param
  pnh_.param<int>("fence_level", fenceLevel, 3);
  pnh_.param<double>("fence_range_height", fenceStruct[0].range.height, 1.4); // 0.9m offsets 0.5m = 1.4m
  pnh_.param<double>("fence_range_width", fenceStruct[0].range.width, 1.6); // 1.1m offsets 0.5m = 1.6m
  fenceStruct[0].range.offset = 0.0;

  fenceStruct[1].range.height = fenceStruct[0].range.height * 1.5; // 1.4m*1.5 = 2.1m
  fenceStruct[1].range.width = fenceStruct[0].range.width * 1.2; // 1.6m*1.2 = 1.92m
  fenceStruct[1].range.offset = 0.0;

  fenceStruct[2].range.height = 0.25;
  fenceStruct[2].range.width = 2;
  fenceStruct[2].range.offset = 3.0;

  for (int i=0 ; i < fenceLevel ; ++i)
  {
    std::cout << "fence_range_height " << i << ": " << fenceStruct[i].range.height << std::endl;
    std::cout << "fence_range_width " << i << ": " << fenceStruct[i].range.width << std::endl;
    std::cout << "fence_range_offset " << i << ": " << fenceStruct[i].range.offset << std::endl;
  }

  // YuAn reduced fenceCount from 50 to 10, add doorCount = 100
  fenceCount = 10;
  doorCount = 70;

  // print param
  std::cout << "########## param ################" << std::endl;
  std::cout << "fence_range_height: " << fenceStruct[0].range.height << std::endl;
  std::cout << "fence_range_width: " << fenceStruct[0].range.width << std::endl;
  std::cout << "fenceCount: " << fenceCount << std::endl;
  std::cout << "doorCount: " << doorCount << std::endl;
  std::cout << "#################################" << std::endl;

  // tf
  transformVec.resize(2);
  try
  {
    /*
    listener[0].waitForTransform("/base_link", "/scan", now, ros::Duration(3.0));
    listener[0].lookupTransform("/base_link", "/scan", ros::Time(0), transformVec[0]); // laser1 to base link
    */
    
    listener[0].waitForTransform("/base_link", "/laser1", now, ros::Duration(3.0));
    listener[0].lookupTransform("/base_link", "/laser1", ros::Time(0), transformVec[0]); // laser1 to base link
    listener[1].waitForTransform("/base_link", "/laser2", now, ros::Duration(3.0));
    listener[1].lookupTransform("/base_link", "/laser2", ros::Time(0), transformVec[1]); // laser2 to base link
    
  }
  catch (tf::TransformException ex)
  {
    ROS_ERROR("%s", ex.what());
    ros::Duration(1.0).sleep();
  }

  // get tf org
  origin_pos[0].x = transformVec[0].getOrigin().x();
  origin_pos[0].y = transformVec[0].getOrigin().y();
  origin_pos[1].x = transformVec[1].getOrigin().x();
  origin_pos[1].y = transformVec[1].getOrigin().y();
  // std::cout << " x1:" << origin_pos[0].x << " y1:" << origin_pos[0].y << " x2:" << origin_pos[1].x << " y2:" << origin_pos[1].y << std::endl; // debug print

  for (int i=0 ; i<4 ; ++i)
  {
    cabinet_leg[i].center_x = 0;
    cabinet_leg[i].center_y = 0;
    cabinet_leg[i].obstacle_radius = 0;
  }

  // draw
  for (int i = 0; i < fenceLevel ; i++)
  {
    fenceStruct[i].flag = 0;
    //drawSquare(i+1, origin_pos[0].x + fenceStruct[i].range.height, origin_pos[0].y + fenceStruct[i].range.width, origin_pos[1].x - fenceStruct[i].range.height, origin_pos[1].y - fenceStruct[i].range.width, 2, vis_pub);
  }

  std::cout << "origin_pos[0].x = " << origin_pos[0].x << ", origin_pos[0].y = " << origin_pos[0].y << std::endl;
  std::cout << "origin_pos[1].x = " << origin_pos[1].x << ", origin_pos[1].y = " << origin_pos[1].y << std::endl;
}

ObsDetect::~ObsDetect()
{
}

/* -------------------------------------------------------------------------- */
/*                                    timer                                   */
/* -------------------------------------------------------------------------- */

void ObsDetect::timerCallback(const ros::TimerEvent &)
{
  drawSquare(0, -0.55, -0.45, 0.55, 0.45, 4, vis_pub); // draw the car

  // draw the fence
  
  for (int i = 0; i < fenceLevel; i++)
  {
    if (fenceStruct[i].flag)
      drawSquare(i+1, origin_pos[0].x + fenceStruct[i].range.height + fenceStruct[i].range.offset, origin_pos[0].y + fenceStruct[i].range.width, origin_pos[1].x - fenceStruct[i].range.height + fenceStruct[i].range.offset, origin_pos[1].y - fenceStruct[i].range.width, 1, vis_pub);
    else
      drawSquare(i+1, origin_pos[0].x + fenceStruct[i].range.height + fenceStruct[i].range.offset, origin_pos[0].y + fenceStruct[i].range.width, origin_pos[1].x - fenceStruct[i].range.height + fenceStruct[i].range.offset, origin_pos[1].y - fenceStruct[i].range.width, 2, vis_pub);
  }
  
}

/* -------------------------------------------------------------------------- */
/*                               subscribe scan                               */
/* -------------------------------------------------------------------------- */

void ObsDetect::scanSubCallback(const sensor_msgs::LaserScan &msg)
{
}

/* -------------------------------------------------------------------------- */
/*                          subscribe mergedCloudSub                          */
/* -------------------------------------------------------------------------- */

void ObsDetect::mergedCloudSubCallback(const sensor_msgs::PointCloud2 &msg)
{
  sensor_msgs::PointCloud out_pointcloud;                           // create a pointclound
  sensor_msgs::convertPointCloud2ToPointCloud(msg, out_pointcloud); //pointclound2 to pointclound
  obstacle_detector::stop stop;

  for (int i = 0; i < fenceLevel ; i++)
  {
    fenceStruct[i].pointCount = 0;
  }


  // fence
  for (int i = 0; i < out_pointcloud.points.size(); i++)
  {
    for (int j = 0; j < fenceLevel; j++)
    {
      if ((out_pointcloud.points[i].x < (origin_pos[0].x + fenceStruct[j].range.height + fenceStruct[j].range.offset)) && (out_pointcloud.points[i].x > (origin_pos[1].x - fenceStruct[j].range.height + fenceStruct[j].range.offset))) // if x point inside the fence
      {
        if ((out_pointcloud.points[i].y < (origin_pos[0].y + fenceStruct[j].range.width)) && (out_pointcloud.points[i].y > (origin_pos[1].y - fenceStruct[j].range.width))) // if y point inside the fence
        {
          fenceStruct[j].pointCount++; // how many point ++
        }
      }
      //std::cout << "fenceStruct[" << j << "].pointCount = " << fenceStruct[j].pointCount << std::endl;
    }
  }

  /*
  // door
  for (int i = 0; i < out_pointcloud.points.size(); i++)
  {
    if ((out_pointcloud.points[i].x < (origin_pos[0].x + fenceStruct[2].range.height + 5)) && (out_pointcloud.points[i].x > (origin_pos[1].x - fenceStruct[2].range.height + 5))) // if x point inside the fence
    {
      if ((out_pointcloud.points[i].y < (origin_pos[0].y + fenceStruct[2].range.width)) && (out_pointcloud.points[i].y > (origin_pos[1].y - fenceStruct[2].range.width))) // if y point inside the fence
      {
        fenceStruct[2].pointCount++; // how many point ++
      }
    }
    //std::cout << "fenceStruct[2].pointCount = " << fenceStruct[2].pointCount << std::endl;
  }
  */
  stopFlag = 0;
  for (int i = 0; i < fenceLevel-1 ; i++)
  {
    if (!(fenceStruct[i].pointCount > fenceCount))
      stopFlag++;
  }

  for (int i = fenceLevel-1 ; i >= 0 ; i--)
  {
    // std::cout << "fence" << i << ":" << fenceStruct[i].pointCount << std::endl;
    if (fenceStruct[i].pointCount > fenceCount) // something inside fence
    {
      fenceStruct[i].flag = 1;
      //if (fenceStruct[i].lastFlag < fenceStruct[i].flag || lastStopFlag < stopFlag) // just at first time
      if (fenceStruct[i].lastFlag < fenceStruct[i].flag) // evertime
      {
        if (i == 0) // fence level sound speed
        {
          ROS_INFO("*** Obs!!! ***");
          stop.fence = 2;
        }
        else if (i == 1)
          ROS_INFO("*** Slower ***");
          stop.fence = 1;
      }
    }
    else
    {
      // std::cout << fenceStruct[i].pointCount << std::endl; // debug print
      fenceStruct[i].flag = 0;
      stop.fence = 0;
    }
    fenceStruct[i].lastFlag = fenceStruct[i].flag; // record last flag
    lastStopFlag = stopFlag;
  }

  if (fenceStruct[2].pointCount > doorCount) // something inside door area
  {
    fenceStruct[2].flag = 1;
    stop.wall = true;
    ROS_INFO("*** Door!! ***");
  }
  else
  {
    fenceStruct[2].flag = 0;
    stop.wall = false;
  }

  stop_pub.publish(stop);
  /*
  if ((stopFlag == fenceLevel-1) || (fenceStruct[2].flag == 1))
  {
    //soundTimer.stop(); // sound timer stop
    //ROS_INFO("*** Stop!! ***");
  }
  */
}


/* -------------------------------------------------------------------------- */
/*                             subscribe obstacle                             */
/* -------------------------------------------------------------------------- */

void ObsDetect::obstacleSubCallback(const obstacle_detector::Obstacles::ConstPtr &msg)
{
  int leg_count = 0;
  //double distance = 0.0;

  double x_diff = 0.0;
  double y_diff = 0.0;
  double distance = 0.0;

  double x_mid = 0.0;
  double y_mid = 0.0;
  double slope = 0.0;
  double perpendicular_slope = 0.0;

  double orient_half_len = 0.45;
  double x_more = 0.0;
  double y_more = 0.0;

  geometry_msgs::Point p1;

  if(!msg->circles.empty()){
    for (int i=0 ; i<msg->circles.size() ; ++i){
      distance = sqrt(msg->circles[i].center.x * msg->circles[i].center.x + msg->circles[i].center.y * msg->circles[i].center.y);

      // if radius is less than 10cm and the distance between lidar and the obstacle's center is less than 30cm
      if ((msg->circles[i].true_radius < 0.1) && (distance < 0.3)){
        drawCircle(i+5, msg->circles[i].center.x, msg->circles[i].center.y, msg->circles[i].radius, 1, vis_pub);
        cabinet_leg[leg_count].center_x = msg->circles[i].center.x;
        cabinet_leg[leg_count].center_y = msg->circles[i].center.y;
        cabinet_leg[leg_count].obstacle_radius = msg->circles[i].true_radius;
        leg_count++;
      }
      else{
        //drawCircle(i+5, msg->circles[i].center.x, msg->circles[i].center.y, msg->circles[i].true_radius, 2, vis_pub);
      }
    }
    //std::cout << "Leg : " << leg_count << std::endl;

    switch(leg_count)
    {
      case 2:
        std::cout << "Leg : 2" << std::endl;
        x_diff = cabinet_leg[0].center_x - cabinet_leg[1].center_x;
        y_diff = cabinet_leg[0].center_y - cabinet_leg[1].center_y;
        x_mid = (cabinet_leg[0].center_x + cabinet_leg[1].center_x)/2;
        y_mid = (cabinet_leg[0].center_y + cabinet_leg[1].center_y)/2;

        // multiply two perpendicular lines' slope equals -1
        slope = y_diff/x_diff;
        perpendicular_slope = (-1.0)/slope;

        // x = sqrt( (hypotenuse^2) / (1 + slope^2) )
        // y = x * slope
        x_more = sqrt((orient_half_len * orient_half_len)/(1 + (perpendicular_slope * perpendicular_slope)));
        x_more *= -1.0;

        y_more = x_more * perpendicular_slope;

        //geometry_msgs::Point p1, p2;
        //geometry_msgs::Point p1;

        p1.x = x_mid + x_more;
        p1.y = y_mid + y_more;

        std::cout << "cabinet.x  = " << p1.x << ", cabinet.y  = " << p1.y << std::endl;

        drawCircle(10, p1.x, p1.y, 0.15, 2, vis_pub);
        //drawLine(cabinet_leg[0], cabinet_leg[1], 4, 3, vis_pub);
      break;

      case 3:
        std::cout << "Leg : 3" << std::endl;

      break;
      
      case 4:
        std::cout << "Leg : 4" << std::endl;
      break;

      default:
      break;
    }
  }

  leg_count = 0;
}

/* -------------------------------------------------------------------------- */
/*                                  marker id                                 */
/*                      square : 0 -> car, 1 -> inner_fence,                  */
/*                               2 -> outer_fence, 3 -> door_detect           */
/*                      line : 4 -> mid_line                                  */
/*                      circle : 5 -> circles                                 */
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */
/*                             marker draw square                             */
/* -------------------------------------------------------------------------- */

void ObsDetect::drawSquare(int id, double x1, double y1, double x2, double y2, int color, ros::Publisher vis_pub)
{

  visualization_msgs::Marker marker;
  marker.header.frame_id = "base_link";
  marker.header.stamp = ros::Time();
  marker.ns = "square";
  marker.id = id;
  marker.type = visualization_msgs::Marker::LINE_STRIP;
  marker.action = visualization_msgs::Marker::ADD;

  marker.scale.x = 0.05;
  marker.color.a = 1.0; // Don't forget to set the alpha!
  switch (color)
  {
  case 0:
    break;
  case 1:
    marker.color.r = 1.0;
    break;
  case 2:
    marker.color.g = 1.0;
    break;
  case 3:
    marker.color.b = 1.0;
    break;
  default:
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    break;
  }

  std::vector<geometry_msgs::Point> pointMsgVec(5);
  int qqX[5] = {0, 0, 1, 1, 0}; // square x
  int qqY[5] = {0, 1, 1, 0, 0}; // square y
  double posX[2] = {x1, x2};
  double posY[2] = {y1, y2};

  for (int i = 0; i < 5; i++)
  {
    pointMsgVec[i].x = posX[qqX[i]];
    pointMsgVec[i].y = posY[qqY[i]];

    marker.points.push_back(pointMsgVec[i]);
  }

  vis_pub.publish(marker);
}

/* -------------------------------------------------------------------------- */
/*                             marker draw circle                             */
/* -------------------------------------------------------------------------- */

void ObsDetect::drawCircle(int id, double center_x, double center_y, double radius, int color, ros::Publisher vis_pub)
{

  visualization_msgs::Marker marker;
  marker.header.frame_id = "base_link";
  marker.header.stamp = ros::Time();
  marker.ns = "circle";
  marker.id = id;
  marker.type = visualization_msgs::Marker::SPHERE;
  marker.action = visualization_msgs::Marker::ADD;
  marker.lifetime = ros::Duration(0.05);

  marker.scale.x = radius;
  marker.scale.y = radius;
  marker.scale.z = 0.01;
  marker.color.a = 0.5; // Don't forget to set the alpha!

  switch (color)
  {
  case 0:
    break;
  case 1:
    marker.color.r = 1.0;
    break;
  case 2:
    marker.color.g = 1.0;
    break;
  case 3:
    marker.color.b = 1.0;
    break;
  default:
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    break;
  }

  marker.pose.position.x = center_x;
  marker.pose.position.y = center_y;

  vis_pub.publish(marker);
}

/* -------------------------------------------------------------------------- */
/*                              marker draw line                              */
/* -------------------------------------------------------------------------- */

void ObsDetect::drawLine(cabinet c1, cabinet c2, int id, int color, ros::Publisher vis_pub)
{

  double x_diff = 0.0;
  double y_diff = 0.0;
  double distance = 0.0;

  double x_mid = 0.0;
  double y_mid = 0.0;
  double slope = 0.0;
  double perpendicular_slope = 0.0;

  double orient_half_len = 0.45;
  double x_more = 0.0;
  double y_more = 0.0;

  visualization_msgs::Marker marker;
  marker.header.frame_id = "base_link";
  marker.header.stamp = ros::Time();
  marker.ns = "line";
  marker.id = id;
  marker.type = visualization_msgs::Marker::ARROW;
  marker.action = visualization_msgs::Marker::ADD;
  marker.lifetime = ros::Duration(0.05);

  /*
  marker.pose.position.x = poseWorld.x();
  marker.pose.position.y = poseWorld.y();
  marker.pose.orientation.w = cos(poseWorld.z()*0.5f);
  marker.pose.orientation.z = sin(poseWorld.z()*0.5f);
  */
  marker.scale.x = 0.05;
  marker.color.a = 0.5; // Don't forget to set the alpha!

  switch (color)
  {
  case 0:
    break;
  case 1:
    marker.color.r = 1.0;
    break;
  case 2:
    marker.color.g = 1.0;
    break;
  case 3:
    marker.color.b = 1.0;
    break;
  default:
    marker.color.r = 1.0;
    marker.color.g = 1.0;
    marker.color.b = 1.0;
    break;
  }

  x_diff = c1.center_x - c2.center_x;
  y_diff = c1.center_y - c2.center_y;

  // multiply two perpendicular lines' slope equals -1
  slope = y_diff/x_diff;
  perpendicular_slope = (-1.0)/slope;

  std::cout << "distance = " << sqrt(x_diff * x_diff + y_diff * y_diff) << std::endl;
  //std::cout << "yaw degree = " << 1/tan(x_diff/y_diff) << std::endl << std::endl;

  x_mid = (c1.center_x + c2.center_x)/2;
  y_mid = (c1.center_y + c2.center_y)/2;

  // x = sqrt( (hypotenuse^2) / (1 + slope^2) )
  // y = x * slope
  x_more = sqrt((orient_half_len * orient_half_len)/(1 + (perpendicular_slope * perpendicular_slope)));
  y_more = x_more * perpendicular_slope;

  geometry_msgs::Point p1, p2;

  p1.x = x_mid + x_more;
  p1.y = y_mid + y_more;

  p2.x = x_mid - x_more;
  p2.y = y_mid - y_more;

  marker.points.push_back(p1);
  marker.points.push_back(p2);

  vis_pub.publish(marker);
}

/* -------------------------------------------------------------------------- */
/*                                    main                                    */
/* -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
  ros::init(argc, argv, "fence");

  ObsDetect ObsDetect;

  ros::spin();

  return 0;
};