class mission(missionType, x_pos, y_pos, yaw):
    def __init__(self):
        self.missionType = missionType
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.yaw = yaw

