from PyQt5 import QtWidgets
from missionPoint_ui_new import Ui_MainWindow
import sys


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
    
        self.ui.pushButton.clicked.connect(self.readMission)
        self.ui.pushButton_2.clicked.connect(self.writeMission)

        self.ui.pushButton_3.clicked.connect(self.clearA)
        self.ui.pushButton_4.clicked.connect(self.clearB)
        self.ui.pushButton_5.clicked.connect(self.clearC)
        self.ui.pushButton_8.clicked.connect(self.clearD)
        self.ui.pushButton_6.clicked.connect(self.clearE)
        self.ui.pushButton_7.clicked.connect(self.clearF)
        self.ui.pushButton_12.clicked.connect(self.clearG)
        self.ui.pushButton_9.clicked.connect(self.clearH)
        self.ui.pushButton_10.clicked.connect(self.clearI)
        self.ui.pushButton_14.clicked.connect(self.clearJ)
        self.ui.pushButton_11.clicked.connect(self.clearK)
        self.ui.pushButton_13.clicked.connect(self.clearL)
        self.ui.pushButton_15.clicked.connect(self.clearM)
        self.ui.pushButton_16.clicked.connect(self.clearN)
        self.ui.pushButton_17.clicked.connect(self.clearO)

        self.A = point('A', '', '', '', '')
        self.B = point('B', '', '', '', '')
        self.C = point('C', '', '', '', '')
        self.D = point('D', '', '', '', '')
        self.E = point('E', '', '', '', '')
        self.F = point('F', '', '', '', '')
        self.G = point('G', '', '', '', '')
        self.H = point('H', '', '', '', '')
        self.I = point('I', '', '', '', '')
        self.J = point('J', '', '', '', '')
        self.K = point('K', '', '', '', '')
        self.L = point('L', '', '', '', '')
        self.M = point('M', '', '', '', '')
        self.N = point('N', '', '', '', '')
        self.O = point('O', '', '', '', '')

        self.bg1 = QtWidgets.QButtonGroup(self)
        self.bg1.addButton(self.ui.radioButton, 1)
        self.bg1.addButton(self.ui.radioButton_2, 2)
        self.bg1.addButton(self.ui.radioButton_3, 3)
        self.bg1.addButton(self.ui.radioButton_4, 4)
        self.bg1.buttonClicked.connect(self.missionChecked)

        self.mission_Path = '/home/user/Dispatch_ws/missionPath/mission_A.txt'
        self.missionPoint_Path = '/home/user/Dispatch_ws/missionPath/missionPoint_A.txt'

    def missionChecked(self):
        sender = self.sender()
        if sender == self.bg1:
            if self.bg1.checkedId() == 1:
                self.mission_Path = '/home/user/Dispatch_ws/missionPath/mission_A.txt'
                self.missionPoint_Path = '/home/user/Dispatch_ws/missionPath/missionPoint_A.txt'
            elif self.bg1.checkedId() == 2:
                self.mission_Path = '/home/user/Dispatch_ws/missionPath/mission_B.txt'
                self.missionPoint_Path = '/home/user/Dispatch_ws/missionPath/missionPoint_B.txt'
            elif self.bg1.checkedId() == 3:
                self.mission_Path = '/home/user/Dispatch_ws/missionPath/mission_C.txt'
                self.missionPoint_Path = '/home/user/Dispatch_ws/missionPath/missionPoint_C.txt'
            elif self.bg1.checkedId() == 4:
                self.mission_Path = '/home/user/Dispatch_ws/missionPath/mission_D.txt'
                self.missionPoint_Path = '/home/user/Dispatch_ws/missionPath/missionPoint_D.txt'

    def writeMission(self):
        Queue = self.ui.textEdit_16.toPlainText()
        Queue = Queue.split(' ')
        print(Queue)

        with open(self.mission_Path, 'w+') as mf:
            mf.write('Mr;')

            with open(self.missionPoint_Path, 'w+') as mpf:
                k = 0
                if Queue == ['']:
                    missionText = ''
                    missionPointText = ''

                    # A
                    if self.ui.textEdit.toPlainText():
                        self.A = point('A', self.ui.textEdit.toPlainText(), self.ui.textEdit_2.toPlainText(), self.ui.textEdit_3.toPlainText(), self.ui.textEdit_33.toPlainText())
                        missionText = '{},{},{},{}'.format(self.A.missionType, self.A.x_pos, self.A.y_pos, self.A.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.A.missionType, self.A.x_pos, self.A.y_pos, self.A.yaw)
                        print('A = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0;')
                        mpf.write(missionPointText)
                    
                    # B
                    if self.ui.textEdit_6.toPlainText():
                        self.B = point('B', self.ui.textEdit_6.toPlainText(), self.ui.textEdit_4.toPlainText(), self.ui.textEdit_5.toPlainText(), self.ui.textEdit_34.toPlainText())
                        missionText = '{},{},{},{}'.format(self.B.missionType, self.B.x_pos, self.B.y_pos, self.B.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.B.missionType, self.B.x_pos, self.B.y_pos, self.B.yaw)
                        print('B = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                    
                    # C
                    if self.ui.textEdit_9.toPlainText():
                        self.C = point('C', self.ui.textEdit_9.toPlainText(), self.ui.textEdit_8.toPlainText(), self.ui.textEdit_7.toPlainText(), self.ui.textEdit_37.toPlainText())
                        missionText = '{},{},{},{}'.format(self.C.missionType, self.C.x_pos, self.C.y_pos, self.C.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.C.missionType, self.C.x_pos, self.C.y_pos, self.C.yaw)
                        print('C = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                    
                    # D
                    if self.ui.textEdit_10.toPlainText():
                        self.D = point('D', self.ui.textEdit_10.toPlainText(), self.ui.textEdit_11.toPlainText(), self.ui.textEdit_12.toPlainText(), self.ui.textEdit_36.toPlainText())
                        missionText = '{},{},{},{}'.format(self.D.missionType, self.D.x_pos, self.D.y_pos, self.D.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.D.missionType, self.D.x_pos, self.D.y_pos, self.D.yaw)
                        print('D = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                    
                    # E
                    if self.ui.textEdit_14.toPlainText():
                        self.E = point('E', self.ui.textEdit_14.toPlainText(), self.ui.textEdit_13.toPlainText(), self.ui.textEdit_15.toPlainText(), self.ui.textEdit_30.toPlainText())
                        missionText = '{},{},{},{}'.format(self.E.missionType, self.E.x_pos, self.E.y_pos, self.E.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.E.missionType, self.E.x_pos, self.E.y_pos, self.E.yaw)
                        print('E = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                    
                    # F
                    if self.ui.textEdit_17.toPlainText():
                        self.F = point('F', self.ui.textEdit_17.toPlainText(), self.ui.textEdit_19.toPlainText(), self.ui.textEdit_18.toPlainText(), self.ui.textEdit_31.toPlainText())
                        missionText = '{},{},{},{}'.format(self.F.missionType, self.F.x_pos, self.F.y_pos, self.F.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.F.missionType, self.F.x_pos, self.F.y_pos, self.F.yaw)
                        print('F = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # G
                    if self.ui.textEdit_21.toPlainText():
                        self.G = point('G', self.ui.textEdit_21.toPlainText(), self.ui.textEdit_22.toPlainText(), self.ui.textEdit_20.toPlainText(), self.ui.textEdit_32.toPlainText())
                        missionText = '{},{},{},{}'.format(self.G.missionType, self.G.x_pos, self.G.y_pos, self.G.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.G.missionType, self.G.x_pos, self.G.y_pos, self.G.yaw)
                        print('G = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # H
                    if self.ui.textEdit_23.toPlainText():
                        self.H = point('H', self.ui.textEdit_23.toPlainText(), self.ui.textEdit_25.toPlainText(), self.ui.textEdit_24.toPlainText(), self.ui.textEdit_29.toPlainText())
                        missionText = '{},{},{},{}'.format(self.H.missionType, self.H.x_pos, self.H.y_pos, self.H.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.H.missionType, self.H.x_pos, self.H.y_pos, self.H.yaw)
                        print('H = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # I
                    if self.ui.textEdit_28.toPlainText():
                        self.I = point('I', self.ui.textEdit_28.toPlainText(), self.ui.textEdit_27.toPlainText(), self.ui.textEdit_26.toPlainText(), self.ui.textEdit_35.toPlainText())
                        missionText = '{},{},{},{}'.format(self.I.missionType, self.I.x_pos, self.I.y_pos, self.I.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.I.missionType, self.I.x_pos, self.I.y_pos, self.I.yaw)
                        print('I = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                    
                    # J
                    if self.ui.textEdit_43.toPlainText():
                        self.J = point('J', self.ui.textEdit_43.toPlainText(), self.ui.textEdit_39.toPlainText(), self.ui.textEdit_40.toPlainText(), self.ui.textEdit_42.toPlainText())
                        missionText = '{},{},{},{}'.format(self.J.missionType, self.J.x_pos, self.J.y_pos, self.J.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.J.missionType, self.J.x_pos, self.J.y_pos, self.J.yaw)
                        print('J = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # K
                    if self.ui.textEdit_38.toPlainText():
                        self.K = point('K', self.ui.textEdit_38.toPlainText(), self.ui.textEdit_45.toPlainText(), self.ui.textEdit_44.toPlainText(), self.ui.textEdit_41.toPlainText())
                        missionText = '{},{},{},{}'.format(self.K.missionType, self.K.x_pos, self.K.y_pos, self.K.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.K.missionType, self.K.x_pos, self.K.y_pos, self.K.yaw)
                        print('K = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # L
                    if self.ui.textEdit_49.toPlainText():
                        self.L = point('L', self.ui.textEdit_49.toPlainText(), self.ui.textEdit_47.toPlainText(), self.ui.textEdit_48.toPlainText(), self.ui.textEdit_46.toPlainText())
                        missionText = '{},{},{},{}'.format(self.L.missionType, self.L.x_pos, self.L.y_pos, self.L.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.L.missionType, self.L.x_pos, self.L.y_pos, self.L.yaw)
                        print('L = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                    
                    # M
                    if self.ui.textEdit_51.toPlainText():
                        self.M = point('M', self.ui.textEdit_51.toPlainText(), self.ui.textEdit_53.toPlainText(), self.ui.textEdit_52.toPlainText(), self.ui.textEdit_50.toPlainText())
                        missionText = '{},{},{},{}'.format(self.M.missionType, self.M.x_pos, self.M.y_pos, self.M.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.M.missionType, self.M.x_pos, self.M.y_pos, self.M.yaw)
                        print('M = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # N
                    if self.ui.textEdit_56.toPlainText():
                        self.N = point('N', self.ui.textEdit_56.toPlainText(), self.ui.textEdit_57.toPlainText(), self.ui.textEdit_55.toPlainText(), self.ui.textEdit_54.toPlainText())
                        missionText = '{},{},{},{}'.format(self.N.missionType, self.N.x_pos, self.N.y_pos, self.N.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.N.missionType, self.N.x_pos, self.N.y_pos, self.N.yaw)
                        print('N = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                    # O
                    if self.ui.textEdit_60.toPlainText():
                        self.O = point('O', self.ui.textEdit_60.toPlainText(), self.ui.textEdit_61.toPlainText(), self.ui.textEdit_59.toPlainText(), self.ui.textEdit_58.toPlainText())
                        missionText = '{},{},{},{}'.format(self.O.missionType, self.O.x_pos, self.O.y_pos, self.O.yaw)
                        missionPointText = '{},{},{},{}\n'.format(self.O.missionType, self.O.x_pos, self.O.y_pos, self.O.yaw)
                        print('O = {}'.format(missionText))

                        mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)
                else:
                    for i in Queue:
                        missionText = ''
                        missionPointText = ''
                        if i == 'A':
                            missionText = '{},{},{},{}'.format(self.A.missionType, self.A.x_pos, self.A.y_pos, self.A.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.A.missionType, self.A.x_pos, self.A.y_pos, self.A.yaw)
                            print('A = {}'.format(missionText))
                        elif i == 'B':
                            missionText = '{},{},{},{}'.format(self.B.missionType, self.B.x_pos, self.B.y_pos, self.B.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.B.missionType, self.B.x_pos, self.B.y_pos, self.B.yaw)
                            print('B = {}'.format(missionText))
                        elif i == 'C':
                            missionText = '{},{},{},{}'.format(self.C.missionType, self.C.x_pos, self.C.y_pos, self.C.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.C.missionType, self.C.x_pos, self.C.y_pos, self.C.yaw)
                            print('C = {}'.format(missionText))
                        elif i == 'D':
                            missionText = '{},{},{},{}'.format(self.D.missionType, self.D.x_pos, self.D.y_pos, self.D.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.D.missionType, self.D.x_pos, self.D.y_pos, self.D.yaw)
                            print('D = {}'.format(missionText))
                        elif i == 'E':
                            missionText = '{},{},{},{}'.format(self.E.missionType, self.E.x_pos, self.E.y_pos, self.E.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.E.missionType, self.E.x_pos, self.E.y_pos, self.E.yaw)
                            print('E = {}'.format(missionText))
                        elif i == 'F':
                            missionText = '{},{},{},{}'.format(self.F.missionType, self.F.x_pos, self.F.y_pos, self.F.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.F.missionType, self.F.x_pos, self.F.y_pos, self.F.yaw)
                            print('F = {}'.format(missionText))
                        elif i == 'G':
                            missionText = '{},{},{},{}'.format(self.G.missionType, self.G.x_pos, self.G.y_pos, self.G.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.G.missionType, self.G.x_pos, self.G.y_pos, self.G.yaw)
                            print('G = {}'.format(missionText))
                        elif i == 'H':
                            missionText = '{},{},{},{}'.format(self.H.missionType, self.H.x_pos, self.H.y_pos, self.H.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.H.missionType, self.H.x_pos, self.H.y_pos, self.H.yaw)
                            print('H = {}'.format(missionText))
                        elif i == 'I':
                            missionText = '{},{},{},{}'.format(self.I.missionType, self.I.x_pos, self.I.y_pos, self.I.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.I.missionType, self.I.x_pos, self.I.y_pos, self.I.yaw)
                            print('I = {}'.format(missionText))
                        elif i == 'J':
                            missionText = '{},{},{},{}'.format(self.J.missionType, self.J.x_pos, self.J.y_pos, self.J.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.J.missionType, self.J.x_pos, self.J.y_pos, self.J.yaw)
                            print('J = {}'.format(missionText))
                        elif i == 'K':
                            missionText = '{},{},{},{}'.format(self.K.missionType, self.K.x_pos, self.K.y_pos, self.K.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.K.missionType, self.K.x_pos, self.K.y_pos, self.K.yaw)
                            print('K = {}'.format(missionText))
                        elif i == 'L':
                            missionText = '{},{},{},{}'.format(self.L.missionType, self.L.x_pos, self.L.y_pos, self.L.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.L.missionType, self.L.x_pos, self.L.y_pos, self.L.yaw)
                            print('L = {}'.format(missionText))
                        elif i == 'M':
                            missionText = '{},{},{},{}'.format(self.M.missionType, self.M.x_pos, self.M.y_pos, self.M.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.M.missionType, self.M.x_pos, self.M.y_pos, self.M.yaw)
                            print('M = {}'.format(missionText))
                        elif i == 'N':
                            missionText = '{},{},{},{}'.format(self.N.missionType, self.N.x_pos, self.N.y_pos, self.N.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.N.missionType, self.N.x_pos, self.N.y_pos, self.N.yaw)
                            print('N = {}'.format(missionText))
                        elif i == 'O':
                            missionText = '{},{},{},{}'.format(self.O.missionType, self.O.x_pos, self.O.y_pos, self.O.yaw)
                            missionPointText = '{},{},{},{}\n'.format(self.O.missionType, self.O.x_pos, self.O.y_pos, self.O.yaw)
                            print('O = {}'.format(missionText))

                        if k == 0:
                            mf.write(str(k) + ',' + missionText + ',omni,0,1.0;')
                        else:
                            mf.write(str(k) + ',' + missionText + ',omni,0,1.0,0;')
                        mpf.write(missionPointText)

                        k += 1
            mf.write('E')

    def readMission(self):
        # clear all
        self.clearA()
        self.clearB()
        self.clearC()
        self.clearD()
        self.clearE()
        self.clearF()
        self.clearG()
        self.clearH()
        self.clearI()
        self.clearJ()
        self.clearK()
        self.clearL()
        self.clearM()
        self.clearN()
        self.clearO()

        with open(self.missionPoint_Path) as f:
            lines = f.readlines()
        
        missionPoints = mission(lines)

        if missionPoints.missionLength >= 1:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[0].split(',')
            self.A = point('A', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit.setText(m_type)
            self.ui.textEdit_2.setText(x_pos)
            self.ui.textEdit_3.setText(y_pos)
            self.ui.textEdit_33.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 2:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[1].split(',')
            self.B = point('B', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_6.setText(m_type)
            self.ui.textEdit_4.setText(x_pos)
            self.ui.textEdit_5.setText(y_pos)
            self.ui.textEdit_34.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 3:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[2].split(',')
            self.C = point('C', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_9.setText(m_type)
            self.ui.textEdit_8.setText(x_pos)
            self.ui.textEdit_7.setText(y_pos)
            self.ui.textEdit_37.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 4:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[3].split(',')
            self.D = point('D', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_10.setText(m_type)
            self.ui.textEdit_11.setText(x_pos)
            self.ui.textEdit_12.setText(y_pos)
            self.ui.textEdit_36.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 5:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[4].split(',')
            self.E = point('E', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_14.setText(m_type)
            self.ui.textEdit_13.setText(x_pos)
            self.ui.textEdit_15.setText(y_pos)
            self.ui.textEdit_30.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 6:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[5].split(',')
            self.F = point('F', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_17.setText(m_type)
            self.ui.textEdit_19.setText(x_pos)
            self.ui.textEdit_18.setText(y_pos)
            self.ui.textEdit_31.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 7:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[6].split(',')
            self.G = point('G', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_21.setText(m_type)
            self.ui.textEdit_22.setText(x_pos)
            self.ui.textEdit_20.setText(y_pos)
            self.ui.textEdit_32.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 8:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[7].split(',')
            self.H = point('H', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_23.setText(m_type)
            self.ui.textEdit_25.setText(x_pos)
            self.ui.textEdit_24.setText(y_pos)
            self.ui.textEdit_29.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 9:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[8].split(',')
            self.I = point('I', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_28.setText(m_type)
            self.ui.textEdit_27.setText(x_pos)
            self.ui.textEdit_26.setText(y_pos)
            self.ui.textEdit_35.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 10:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[9].split(',')
            self.J = point('J', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_43.setText(m_type)
            self.ui.textEdit_39.setText(x_pos)
            self.ui.textEdit_40.setText(y_pos)
            self.ui.textEdit_42.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 11:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[10].split(',')
            self.K = point('K', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_38.setText(m_type)
            self.ui.textEdit_45.setText(x_pos)
            self.ui.textEdit_44.setText(y_pos)
            self.ui.textEdit_41.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 12:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[11].split(',')
            self.L = point('L', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_49.setText(m_type)
            self.ui.textEdit_47.setText(x_pos)
            self.ui.textEdit_48.setText(y_pos)
            self.ui.textEdit_46.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 13:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[12].split(',')
            self.M = point('M', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_51.setText(m_type)
            self.ui.textEdit_53.setText(x_pos)
            self.ui.textEdit_52.setText(y_pos)
            self.ui.textEdit_50.setText(yaw.split('\n')[0])
        
        if missionPoints.missionLength >= 14:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[12].split(',')
            self.N = point('N', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_56.setText(m_type)
            self.ui.textEdit_57.setText(x_pos)
            self.ui.textEdit_55.setText(y_pos)
            self.ui.textEdit_54.setText(yaw.split('\n')[0])

        if missionPoints.missionLength >= 15:
            m_type, x_pos, y_pos, yaw = missionPoints.missionPoints[12].split(',')
            self.O = point('O', m_type, x_pos, y_pos, yaw.split('\n')[0])
            self.ui.textEdit_60.setText(m_type)
            self.ui.textEdit_61.setText(x_pos)
            self.ui.textEdit_59.setText(y_pos)
            self.ui.textEdit_58.setText(yaw.split('\n')[0])

    def clearA(self):
        self.A = point('A', '', '', '', '')
        self.ui.textEdit.setText('')
        self.ui.textEdit_2.setText('')
        self.ui.textEdit_3.setText('')
        self.ui.textEdit_33.setText('')

    def clearB(self):
        self.B = point('B', '', '', '', '')
        self.ui.textEdit_6.setText('')
        self.ui.textEdit_4.setText('')
        self.ui.textEdit_5.setText('')
        self.ui.textEdit_34.setText('')
        
    def clearC(self):
        self.C = point('C', '', '', '', '')
        self.ui.textEdit_9.setText('')
        self.ui.textEdit_8.setText('')
        self.ui.textEdit_7.setText('')
        self.ui.textEdit_37.setText('')
    
    def clearD(self):
        self.D = point('D', '', '', '', '')
        self.ui.textEdit_10.setText('')
        self.ui.textEdit_11.setText('')
        self.ui.textEdit_12.setText('')
        self.ui.textEdit_36.setText('')
    
    def clearE(self):
        self.E = point('E', '', '', '', '')
        self.ui.textEdit_14.setText('')
        self.ui.textEdit_13.setText('')
        self.ui.textEdit_15.setText('')
        self.ui.textEdit_30.setText('')

    def clearF(self):
        self.F = point('F', '', '', '', '')
        self.ui.textEdit_17.setText('')
        self.ui.textEdit_19.setText('')
        self.ui.textEdit_18.setText('')
        self.ui.textEdit_31.setText('')

    def clearG(self):
        self.G = point('G', '', '', '', '')
        self.ui.textEdit_21.setText('')
        self.ui.textEdit_22.setText('')
        self.ui.textEdit_20.setText('')
        self.ui.textEdit_32.setText('')

    def clearH(self):
        self.H = point('H', '', '', '', '')
        self.ui.textEdit_23.setText('')
        self.ui.textEdit_25.setText('')
        self.ui.textEdit_24.setText('')
        self.ui.textEdit_29.setText('')

    def clearI(self):
        self.I = point('I', '', '', '', '')
        self.ui.textEdit_28.setText('')
        self.ui.textEdit_27.setText('')
        self.ui.textEdit_26.setText('')
        self.ui.textEdit_35.setText('')
        
    def clearJ(self):
        self.J = point('J', '', '', '', '')
        self.ui.textEdit_43.setText('')
        self.ui.textEdit_39.setText('')
        self.ui.textEdit_40.setText('')
        self.ui.textEdit_42.setText('')
        
    def clearK(self):
        self.K = point('K', '', '', '', '')
        self.ui.textEdit_38.setText('')
        self.ui.textEdit_45.setText('')
        self.ui.textEdit_44.setText('')
        self.ui.textEdit_41.setText('')

    def clearL(self):
        self.L = point('L', '', '', '', '')
        self.ui.textEdit_49.setText('')
        self.ui.textEdit_47.setText('')
        self.ui.textEdit_48.setText('')
        self.ui.textEdit_46.setText('')

    def clearM(self):
        self.M = point('M', '', '', '', '')
        self.ui.textEdit_51.setText('')
        self.ui.textEdit_53.setText('')
        self.ui.textEdit_52.setText('')
        self.ui.textEdit_50.setText('')

    def clearN(self):
        self.N = point('N', '', '', '', '')
        self.ui.textEdit_56.setText('')
        self.ui.textEdit_57.setText('')
        self.ui.textEdit_55.setText('')
        self.ui.textEdit_54.setText('')

    def clearO(self):
        self.O = point('O', '', '', '', '')
        self.ui.textEdit_60.setText('')
        self.ui.textEdit_61.setText('')
        self.ui.textEdit_59.setText('')
        self.ui.textEdit_58.setText('')

# mission point define
class mission():
    def __init__(self, missionQueue):
        self.missionQueue = missionQueue
        self.missionLength = len(self.missionQueue)
        self.missionPoints = []
        for i in missionQueue:
            i.split(',')
            self.missionPoints.append(i)

class point():
    def __init__(self, name, missionType, x_pos, y_pos, yaw):
        self.name = name
        self.missionType = missionType
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.yaw = yaw

if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
