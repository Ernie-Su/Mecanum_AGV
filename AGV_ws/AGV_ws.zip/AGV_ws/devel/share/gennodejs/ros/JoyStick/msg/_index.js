
"use strict";

let joystick = require('./joystick.js');

module.exports = {
  joystick: joystick,
};
