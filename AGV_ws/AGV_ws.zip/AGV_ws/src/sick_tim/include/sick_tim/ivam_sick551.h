#include <sick_tim/sick_tim_common_usb.h>
#include <sick_tim/sick_tim_common_tcp.h>
#include <sick_tim/sick_tim_common_mockup.h>
#include <sick_tim/sick_tim551_2050001_parser.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <std_msgs/String.h>

#include <diagnostic_updater/diagnostic_updater.h>
#include <diagnostic_updater/publisher.h>

#include <dynamic_reconfigure/server.h>
#include <sick_tim/SickTimConfig.h>

#include "abstract_parser.h"

#include <tf/transform_broadcaster.h>

class ivam_sick551{
public:

	ivam_sick551();
	~ivam_sick551();

    void update();
	void broadcast_transform();

public: 


	float *ranges_1;
	float *ranges_2;

	int check_device_1;
	int check_device_2;


	sensor_msgs::LaserScan scan_data_;

	sensor_msgs::LaserScan scan_data_2;



	ros::Publisher scan_data_publisher_;


	ros::Publisher scan_data_publisher_2;


	//==========================================//
    tf::TransformBroadcaster tf_broadcaster_;
    tf::TransformBroadcaster tf_broadcaster_2;

    tf::Vector3 transform_vector_laser_1_;
    tf::Vector3 transform_vector_laser_2_;


    //! Scan field of view parameters
	unsigned int field_of_view_;
	unsigned int start_scan_;
	unsigned int end_scan_;

    //! Send Transform or not
    bool send_transform_;
 

    ros::NodeHandle nodeHandle_;


    std::string frame_id_1_;
    std::string frame_id_2_;
};