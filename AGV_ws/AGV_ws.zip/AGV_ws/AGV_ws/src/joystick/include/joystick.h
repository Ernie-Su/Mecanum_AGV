#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <iostream>
#include <fcntl.h>
#include <pthread.h>
#include <math.h>
#include <linux/joystick.h>
#include <vector>
#include <unistd.h>
#include <boost/thread.hpp>
#include <Eigen/Geometry>

#include <ros/ros.h>
#include <geometry_msgs/Point.h>

#include "JoyStick/joystick.h"

using namespace std;

// 220506 YuAn Enlarged the whole Joystick's buttons and axes.

// Button
// MODE and VIBRATION have no Button ID

#define PUSH_BUTTON_A 0
#define PUSH_BUTTON_B 1
#define PUSH_BUTTON_X 2
#define PUSH_BUTTON_Y 3
#define PUSH_BUTTON_LB 4
#define PUSH_BUTTON_RB 5
#define PUSH_BUTTON_BACK 6
#define PUSH_BUTTON_START 7
#define PUSH_BUTTON_LOGITECH 8
#define PUSH_BUTTON_LEFT_AXIS 9
#define PUSH_BUTTON_RIGHT_AXIS 10

// Axis 
// Range -> (-32767 ~ 32767)
// Right = Positive, Left = Negative

// Axis[0] -> Left Axis X (Init = 0)
// Axis[1] -> Left Axis Y (Init = 0)
// Axis[2] -> LT  (Init = -32767)
// Axis[3] -> Right Axis X (Init = 0)
// Axis[4] -> Right Axis Y (Init = 0)
// Axis[5] -> RT  (Init = -32767)
// Axis[6] -> Horizontal Cross Button (Init = 0, Left = -32767, Right = 32767)
// Axis[7] -> Vertical Cross Button (Init = 0, Up = -32767, Down = 32767)

#define LEFT_AXIS_X 0 // Axis[0]
#define LEFT_AXIS_Y 1 // Axis[1]
#define TRIGGER_LT 2 // Axis[2]
#define RIGHT_AXIS_X 3 // Axis[3]
#define RIGHT_AXIS_Y 4 // Axis[4]
#define TRIGGER_RT 5 // Axis[5]
#define HORI_CROSS_BUTTON 6 // Axis[6]
#define VERT_CROSS_BUTTON 7 // Axis[7]

struct joystick_position {
    float theta, r, x, y;
};

struct joystick_state {
    vector<signed short> button;
    vector<signed short> axis;
};

class Joystick
{
public:
    Joystick(char *joystick_dev);
    ~Joystick();
    void readEv();
    void RevProcess(double receive_period);
    joystick_position joystickPosition(int n);
    bool buttonPressed(int n);
    bool buttonPressed_LRT(int n);
    bool checkPause();
    ssize_t recvtimeout(int ss, js_event *buf, int timeout);
    
    bool active;

private:
   pthread_t thread;
   
   int joystick_fd;
   js_event *joystick_ev;
   joystick_state *joystick_st;
   __u32 version;
   __u8 axes;
   __u8 buttons;
   char name[256];

   bool isPause;
   int btn_id;
   int btn_last;

   boost::thread* receive_thread_;
   ros::NodeHandle nodeHandle_;
   ros::Publisher Point_data_publisher_;
   geometry_msgs::Point Point_data_;
   joystick_position leftAxis, rightAxis;

};

struct joystick{
	int btn_id;
	int btn_last;
    float x;
    float y;
    float z;
};

#endif // JOYSTICK_H