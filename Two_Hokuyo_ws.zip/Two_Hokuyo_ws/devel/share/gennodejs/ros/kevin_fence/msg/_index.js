
"use strict";

let stop = require('./stop.js');

module.exports = {
  stop: stop,
};
